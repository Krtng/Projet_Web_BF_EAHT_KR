document.addEventListener('DOMContentLoaded', function() {
  // When the event DOMContentLoaded occurs, it is safe to access the DOM
  window.addEventListener('scroll', myFunctionforsticky);
  

var headerNav = document.getElementById("scrollbar");
var sticky = headerNav.offsetTop;

 function myFunctionforsticky() {
 if (window.pageYOffset > sticky) {
   headerNav.classList.add("sticky");
   document.getElementById("icone").style.visibility="visible";  
 } else {
   headerNav.classList.remove("sticky");
   document.getElementById("icone").style.visibility="hidden"; 
 }
 }     
      
});


function invisible(){ 
document.getElementById("giveup").style.visibility="hidden";
}

function invisibleicone(){ 
document.getElementById("icone").style.visibility="hidden";
}

function loading(){
    document.getElementById("giveup").style.visibility="hidden";
    document.getElementById("blague").style.visibility="hidden";
    document.getElementById("categorie").style.visibility="hidden";
}


function requete(){
    
    var messageerror = document.getElementById("messageerror");
    messageerror.innerHTML = "";
    
fetch("https://sv443.net/jokeapi/v2/joke/Any?blacklistFlags=nsfw,racist,sexist")
    .then(response => response.json())
    .then(function (donne) {
    
    document.getElementById("giveup").style.visibility="hidden";

   // alert('Click on the button !');
    console.log(donne)
    
    if(donne["error"] == true){
        var messageerror = document.getElementById("messageerror");
        var reponse = document.getElementById("reponse");
        var questionid = document.getElementById("questionid");
        document.getElementById("giveup").style.visibility="hidden";
        document.getElementById("blague").style.visibility="hidden";   
        document.getElementById("categorie").style.visibility="hidden";   
        messageerror.innerHTML = "L'identifiant de la blague est incorrect<br>(Elle ne devait surement pas être très drôle...)";
        reponse.innerHTML = "";
        questionid.innerHTML = "";
        return;
    }
    if(donne["error"] == false){  
        var messageerror = document.getElementById("messageerror");
        messageerror.innerHTML = "";
    } 
    
    document.getElementById("blague").style.visibility="visible";   
    document.getElementById("categorie").style.visibility="visible";
    
    var joke;
    var tabid = donne["id"];
    var type = donne["type"];
    console.log(tabid); 
    
    var caregorie = document.getElementById("categorie");
    var reponse = document.getElementById("reponse");
    var questionid = document.getElementById("questionid");
    
    if (donne["category"] == "Programming"){
        categorie.innerHTML = "Catégorie : Programmation";
    }
    else if(donne["category"] == "Miscellaneous"){
        categorie.innerHTML = "Catégorie : Divers";
    }
    else if(donne["category"] == "Dark"){
        categorie.innerHTML = "Catégorie : Sombre";
    }
    
    
    if( type == "single")
    {
        document.getElementById("giveup").style.visibility="hidden";
        
        joke = donne["joke"].replace(/\n/g,"<br>");
        reponse.innerHTML = joke; 
        questionid.innerHTML = "Blague nº " + tabid + " - Format : Une partie";
        console.log(joke);
    }

 
    if( type == "twopart")
    {
        
        joke = donne["setup"].replace(/\n/g,"<br>");
        console.log(joke);
        reponse.innerHTML = joke; 
        questionid.innerHTML = "Blague nº " + tabid + " - Format : Deux parties";
        
        document.getElementById("giveup").disabled = true; //le bouton est désactiver
        
         var wait = 6;
            var intervalle = setInterval(function () {
                const btn = document.getElementById("bouton");
                const btn2 = document.getElementById("idbouton");
                
                
                btn.addEventListener('click', event => {
                    clearInterval(intervalle);
                });
                btn2.addEventListener('click', event => {
                    clearInterval(intervalle);
                });
                
                
                document.getElementById("giveup").style.visibility="visible";
                document.getElementById('giveup').textContent = "Regarder la réponse dans "+ (--wait) + " secondes";
                giveup.classList.add("attente");
                
               
                if (wait <= 0) {  //pendant 10 sec
                    document.getElementById('giveup').textContent = "Réponse";
                    clearInterval(intervalle);
                    document.getElementById("giveup").disabled = false;
                    giveup.classList.remove("attente");
                }  
            }, 1000);
        
        const t = document.getElementById("giveup");
        
        answer = donne["delivery"].replace(/\n/g,"<br>");

        t.addEventListener('click', event => {
            
            reponse.innerHTML = joke + "<br><br>" + answer;
            console.log(reponse);
        });
    }
    
    
});

}


function Idsearch(){
     
    
    var rechercheid = document.getElementById("rechercheid").value;
    console.log(rechercheid);
    
    
fetch("https://sv443.net/jokeapi/v2/joke/Any?blacklistFlags=nsfw,racist,sexist&idRange=" + rechercheid)
    .then(response => response.json())
    .then(function (donne) {
    document.getElementById("giveup").style.visibility="hidden";

   // alert('Click on the button !');
    console.log(donne)
    
    
    if (donne["error"] == true){
        var messageerror = document.getElementById("messageerror");
        var reponse = document.getElementById("reponse");
        var questionid = document.getElementById("questionid");
        document.getElementById("giveup").style.visibility="hidden";
        document.getElementById("blague").style.visibility="hidden";   
        document.getElementById("categorie").style.visibility="hidden";
        messageerror.innerHTML = "L'identifiant de la blague est incorrect<br>(Elle ne devait surement pas être très drôle...)";
        reponse.innerHTML = "";
        questionid.innerHTML = "";
        return;
    }
    
    if(donne["error"] == false){  
        var messageerror = document.getElementById("messageerror");
        messageerror.innerHTML = "";
    } 
    
    
    document.getElementById("blague").style.visibility="visible";   
    document.getElementById("categorie").style.visibility="visible";
    
    var joke;
    var tabid = donne["id"];
    var type = donne["type"];
    console.log(tabid); 
    
    var categorie = document.getElementById("categorie");
    var reponse = document.getElementById("reponse");
    var questionid = document.getElementById("questionid");
    
    if (donne["category"] == "Programming"){
        categorie.innerHTML = "Catégorie : Programmation";
    }
    else if(donne["category"] == "Miscellaneous"){
        categorie.innerHTML = "Catégorie : Divers";
    }
    else if(donne["category"] == "Dark"){
        categorie.innerHTML = "Catégorie : Sombre";
    }
    
    if( type == "single")
    {
        document.getElementById("giveup").style.visibility="hidden";
        
        joke = donne["joke"].replace(/\n/g,"<br>");
        reponse.innerHTML = joke; 
        questionid.innerHTML = "Blague nº " + tabid + " - Format : Une partie";
        console.log(joke);
    }
 
    if( type == "twopart")
    {
        
        joke = donne["setup"].replace(/\n/g,"<br>");
        console.log(joke);
        reponse.innerHTML = joke; 
        questionid.innerHTML = "Blague nº " + tabid + " - Format : Deux parties";
        
        document.getElementById("giveup").disabled = true; //le bouton est désactiver
        
         var wait = 6;
            var intervalle = setInterval(function () {
                const btn = document.getElementById("bouton");
                const btn2 = document.getElementById("idbouton");
                
                btn.addEventListener('click', event => {
                    clearInterval(intervalle);
                });
                btn2.addEventListener('click', event => {
                    clearInterval(intervalle);
                });
                
                document.getElementById("giveup").style.visibility="visible";
                document.getElementById('giveup').textContent = "Regarder la réponse dans "+ (--wait) + " secondes";
                giveup.classList.add("attente");
        
                
                
                if (wait <= 0) {  //pendant 10 sec
                    document.getElementById('giveup').textContent = "Réponse";
                    clearInterval(intervalle);
                    document.getElementById("giveup").disabled = false;
                    giveup.classList.remove("attente");
                }  
            }, 1000);
        
        const t = document.getElementById("giveup");
        
        answer = donne["delivery"].replace(/\n/g,"<br>");

        t.addEventListener('click', event => {
            
            reponse.innerHTML = joke + "<br><br>" + answer;
            console.log(reponse);
        });
    }
    
    
    });

}



function lireFichier(){

var request = new XMLHttpRequest();
request.open('GET', "test.json");  // requette XML pour lire le fichier en local
request.responseType = 'text';
request.send();
    
    request.onload = function() {
  var texte = request.response; //JSON.parse() pour le convertir en format json
        console.log(texte);
        
  
}
   
console.log(request);
    
}

/*
function ecrireFichier(){

//var request = window.ActiveXObject ? new ActiveXObject("Microsoft.XMLHTTP") : new XMLHttpRequest();
var request = new XMLHttpRequest();
//request.onreadystatechange=function(){    };
request.open('PUT', "test.json"); //POST PUT
//request.responseType = 'text';


request.send(); 
    
    request.response = "text";

//request.response = request.response + "voila";
    
    request.onload = function() {
  var texte = request.response;
        
   var nouvo = JSON.parse(request.response);
        console.log(texte);
        console.log(nouvo);
}
   
console.log(request);
    
}

*/



function loadFile() {
    var input, file, fr;

    if (typeof window.FileReader !== 'function') {
      alert("The file API isn't supported on this browser yet.");
      return;
    }

    input = document.getElementById('fileinput');
    if (!input) {
      alert("Um, couldn't find the fileinput element.");
    }
    else if (!input.files) {
      alert("This browser doesn't seem to support the `files` property of file inputs.");
    }
    else if (!input.files[0]) {
      alert("Please select a file before clicking 'Load'");
    }
    else {
      file = input.files[0];
      fr = new FileReader();
      fr.onload = receivedText;
      fr.readAsText(file);
    }

    function receivedText(e) {
      let lines = e.target.result;
      var newArr = JSON.parse(lines); 
        console.log(newArr);
    }
  }


/*
fetch("test.json")
  .then(response => response.json())
  .then(json => console.log(json));
*/
/*


//console.log(requete());
/*
var name;

window.onload = function () {

  name = document.getElementById("recherche").value;
    //var str = ((document.getElementById("recherche")||{}).value)||"";
    console.log(name);
}
*/

console.log('Cette fonction est exécutée une fois quand la page est chargée.'); 
 